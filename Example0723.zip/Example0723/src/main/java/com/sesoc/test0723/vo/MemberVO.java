package com.sesoc.test0723.vo;

import lombok.Data;

@Data
public class MemberVO {
	private String member_id;
	private String member_pw;
	private String member_nm;
	private String member_birth;
	private String member_indate;
}
