package com.sesoc.web4.vo;

import lombok.Data;

@Data
public class MemberVo {

	private String id;
	private String pw;
	private String phone;
	
}
