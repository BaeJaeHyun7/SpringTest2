package com.sesoc.subject1.vo;

import lombok.Data;

@Data
public class MemberVo {
	private String id, pw, phone;
	
}
