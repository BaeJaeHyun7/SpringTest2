package com.sesoc.web0.vo;

import java.util.ArrayList;

import lombok.Data;

@Data
public class MemberVo {

	private String id;
	private String pw;
	private String name;
	private String hobby;
	private String gender;
	private String introduce;
	
	
}
