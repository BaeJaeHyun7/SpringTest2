package com.scit.web9.vo;

import lombok.Data;

@Data
public class MemberVo {
	
	private String member_id;
	private String member_pw;
	private String member_nm;
	private String member_birth;
	private String member_indate;

}
