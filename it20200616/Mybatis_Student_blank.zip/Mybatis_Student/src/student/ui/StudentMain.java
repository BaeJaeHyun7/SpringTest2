package student.ui;

public class StudentMain {

	public static void main(String[] args) {
		StudentUI ui = new StudentUI();
	}
}
