
public class SchoolMain {

	public static void main(String[] args) {
		SchoolUI ui = new SchoolUI();
		ui.exec();
	}
}
