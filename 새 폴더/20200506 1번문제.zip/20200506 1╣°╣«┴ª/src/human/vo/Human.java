package human.vo;


class Human {
	public String id;
	public String pw;
	public String name;
}
