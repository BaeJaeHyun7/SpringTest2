package calc.main;

public class CalcMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
