package calc.manager;

import java.util.Scanner;

import calc.vo.Calc;

public class CalcManager {
	
	Scanner sc = new Scanner(System.in);
	
	
	
	public CalcManager() {
		
		while(true) {
			printMenu();
			choiceMenu();
		}		
	}
	
	public void printMenu() {
		System.out.println("===============");
		System.out.println("1.���ϱ�");
		System.out.println("2.����");
		System.out.println("3.���ϱ�");
		System.out.println("4.������");
		System.out.println("===============");		
	}
	
	public void choiceMenu() {
		System.out.println("���� : ");
		int choice = sc.nextInt();
		switch (choice) {
		
		case 1 : 
			
			break;
			
		case 2 :
			
			break;
			
		case 3 :
			
			break;
			
		case 4 : 
	
	break;

		default:System.out.println("�߸��Է��ϼ̽��ϴ�");
			break;
		}
		
		public Calc calcInsert() {
			
			System.out.println("ù��° ���ڸ� �Է��Ͻÿ�");
			int inputNum1 = sc.nextInt();
			System.out.println("�ι�° ���ڸ� �Է��Ͻÿ�");
			int inputNum2 = sc.nextInt();
			
			Calc c = new Calc(inputNum1 , inputNum2);
			return c;
			
		}
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
