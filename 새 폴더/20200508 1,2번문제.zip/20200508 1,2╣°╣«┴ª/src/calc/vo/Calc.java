package calc.vo;

public class Calc {

	
	public int num1;
	public int num2;
	
	
	
	public Calc(int num1, int num2) {
		
		this.num1 = num1;
		this.num2 = num2;
	}

	public int sum(int num1, int num2) {
		return num1 + num2;
	}
	
	public int minus(int num1, int num2) {
		return num1 - num2;
	}
	
	public int multiply(int num1, int num2) {
		return num1 * num2;
	}
	
	public int dividing(int num1, int num2) {
		return num1 / num2;
	}
	
	
	
	public void printInfo() {
		System.out.println("=============");
		System.out.println("1.���ϱ�");
		System.out.println("2.����");
		System.out.println("3.���ϱ�");
		System.out.println("4.������");
		System.out.println("=============");
		
	}
	
	
	
	
	
	
}
