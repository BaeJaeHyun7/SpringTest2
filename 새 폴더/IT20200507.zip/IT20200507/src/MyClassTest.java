
public class MyClassTest {

public static void main(String[] args) {
	
	MyClass mc = new MyClass(20, "ȫ�浿", true);
	
	MyClass mc2 = new MyClass();
	
	
	mc2.setAge(30);
	
	



}
}