package member.vo;

public class Member {
	
	private String name;
	private String phone;
	private int age;
	
	public String getName() {
		return name;
	}
	public void setName(String newName) {
		this.name = newName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String newPhone) {
		this.phone = newPhone;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int newAge) {
		this.age = newAge;
	}
	
	
	
	
	
	
	
	
	

}
