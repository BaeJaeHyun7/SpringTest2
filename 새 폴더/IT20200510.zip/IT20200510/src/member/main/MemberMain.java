package member.main;

import member.manager.MemberManager;

public class MemberMain {

	public static void main(String[] args) {
		
		new MemberManager();

	}

}
