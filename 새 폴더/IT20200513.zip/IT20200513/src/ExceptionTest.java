
public class ExceptionTest {

	public static void main(String[] args) {
		
		
		
		
		
		try {
			
			int a = 10, b = 0;
			System.out.println("����");
			System.out.println(a/b);
			System.out.println("��");
			
		} catch (Exception e) {
			System.out.println("������ �Է��Ͻÿ�");
		}
		
			
				
		
		
		
		
		/*try {
		int a = 10, b = 0;
		System.out.println("����");
		System.out.println(a/b);
		System.out.println("��");
		}
		
		catch(ArithmeticException e) {
			System.out.println("���� ĳġ : "+e.getMessage());
		
	}*/

}
}