
public class StringTest2 {

	public static void main(String[] args) {
		
		String str7 = "Hello World!";
		int lastIndexOfNum = str7.lastIndexOf("o");
		System.out.println(lastIndexOfNum);
		
		String str8 = "Hello World!";
		String subStr = str8.substring(2, 8);
		System.out.println(subStr);
		
		String str9 = "star.a.r.123.jpg";
		int extNum = str9.lastIndexOf(".");
		String ext = str9.substring(extNum+1);
		System.out.println("Ȯ���ڴ� : "+ext);
		
		

	}

}
