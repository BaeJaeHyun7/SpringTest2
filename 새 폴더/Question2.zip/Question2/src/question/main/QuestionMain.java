package question.main;

import question.manager.QuestionManager;

public class QuestionMain {

	public static void main(String[] args) {
		new QuestionManager();
	}

}
