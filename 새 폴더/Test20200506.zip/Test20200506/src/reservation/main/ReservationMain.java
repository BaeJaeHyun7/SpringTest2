package reservation.main;

import reservation.manager.ReservationManager;

public class ReservationMain {

	public static void main(String[] args) {
		
		new ReservationManager();

	}

}
