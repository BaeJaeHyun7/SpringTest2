public class Customer {
	
	String name;
	String phone;
	String carNum;
	String place;
	
	// ������ �����
	// alt + shift + s  -> o
	public Customer(String name, String phone, String carNum, String place) {
		this.name = name;
		this.phone = phone;
		this.carNum = carNum;
		this.place = place;
	}
	
	
	
}
