package com.test.housebook.vo;

import lombok.Data;

@Data
public class AccountVO {
	private String acc_id;
	private String acc_nm;
	private String acc_pw;
}
