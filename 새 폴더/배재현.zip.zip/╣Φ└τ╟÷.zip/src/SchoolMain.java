
public class SchoolMain {

	public static void main(String[] args) {
		
		SchoolUI su = new SchoolUI();
		su.exec();

	}

}
