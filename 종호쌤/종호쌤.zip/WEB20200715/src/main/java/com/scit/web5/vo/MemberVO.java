package com.scit.web5.vo;

import lombok.Data;

@Data
public class MemberVO {

	private String user_id;
	private String user_pw;
	private String user_nm;
	private String user_gender;
	private String[] user_hobby;
}
